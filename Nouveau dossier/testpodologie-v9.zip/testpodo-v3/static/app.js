// app.js non utilisé — logique intégrée dans quiz.html
